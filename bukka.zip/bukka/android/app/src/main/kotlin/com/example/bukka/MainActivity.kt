package com.example.bukka

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
