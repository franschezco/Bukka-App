class Meal {
  final String id;
  final String name;
  final double price;
  final String img;
  final String category;
  final String description;

 Meal({required this.id, required this.name, required this.price,required this.img, required this.category, required this.description});
}
