import 'package:flutter/material.dart';
class CheckoutScreen extends StatelessWidget {
  static const String  routeName = '/checkout';
  static Route route(){
    return MaterialPageRoute(builder:(_) =>CheckoutScreen(), settings: RouteSettings(name: routeName));
  }
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
