import 'package:get/get.dart';
import 'package:flutter/material.dart';
class SearchController extends GetxController{

}