import 'package:bukka/screens/home/HomeController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'SearchController.dart';

class SearchScreen extends GetView<SearchController> {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(child: Center(
        child: Text('Search page',style: TextStyle(fontSize: 20),),
      ),)
    );
  }
}
