import 'package:bukka/screens/home/HomeController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'OrdersController.dart';

class OrderScreen extends GetView<OrderController> {
  const OrderScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(child: Center(
        child: Text('Order page',style: TextStyle(fontSize: 20),),
      ),)
    );
  }
}
