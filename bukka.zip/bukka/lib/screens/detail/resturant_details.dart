import 'package:flutter/material.dart';
class ResturantDetailScreen extends StatelessWidget {
  static const String  routeName = '/restuarantdetail';
  static Route route(){
    return MaterialPageRoute(builder:(_) => ResturantDetailScreen(), settings: RouteSettings(name: routeName));
  }
  const ResturantDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
